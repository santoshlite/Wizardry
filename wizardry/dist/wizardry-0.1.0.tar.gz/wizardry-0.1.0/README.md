## What is it?

Wizardry is a CLI for building powerful algorithmic trading strategies faster and easier (for Lean/QuantConnect)

## Installation

```
pip install wizardry
```
